import shutil
import os

#Find file and folders
def find_files_and_folders(path):
    for root, dir, files in os.walk(path):
        print(f"Current directory: {root}")
        print("Directories:")
        for directory in dir:
            print(os.path.join(root, directory))
        print(("Files:"))
        for file in files:
            print(os.path.join(root, file))
        print("------------------------------------------------")
# print(os.walk("C:\Users\conne\OneDrive\Documents\image and text folder"))/
find_files_and_folders("C:/Users/conne/OneDrive/Documents/image and text folder")
shutil.make_archive('myNewZip', 'zip', 'C:/Users/conne/OneDrive/Documents/image and text folder')